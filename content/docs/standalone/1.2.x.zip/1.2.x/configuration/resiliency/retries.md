---
title: Retries
weight: 10
description: Configure automatic retry attempts for failed backend requests.
---

Attaches to: {{< badge content="Route" path="/configuration/routes/">}}

When a backend request fails, agentgateway can be configured to *{{< gloss "Retry" >}}retry{{< /gloss >}}* the request.
When a retry is attempted, a different backend will be preferred (if possible).

```yaml
retry:
  # total number of attempts allowed.
  # Note: 1 attempt implies no retries; the initial attempt is included in the content.
  attempts: 3
  # Optional; if set, a delay between each additional attempt
  backoff: 500ms
  # A list of HTTP response codes to consider retry-able.
  # In addition, retries are always permitted if the request to a backend was never started.
  codes: [429, 500, 503]
```

When a request has retries enabled and an HTTP body, the request body will be buffered.
If the total body size exceeds a threshold size, retries are disabled.