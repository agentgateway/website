---
title: Mirroring
weight: 10
description: Send copies of requests to alternative backends for shadow testing.
---

Attaches to: {{< badge content="Route" path="/configuration/routes/">}} {{< badge content="Backend" path="/configuration/backends/">}}

Request {{< gloss "Mirroring" >}}mirroring{{< /gloss >}} allows sending a copy of each request to an alterative backend.
These request will not be retried if they fail.

```yaml
requestMirror:
  backend:
    host: localhost:8080
  # Mirror 50% of request
  percentage: 0.5
```