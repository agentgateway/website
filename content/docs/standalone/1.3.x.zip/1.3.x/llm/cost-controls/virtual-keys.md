---
title: Virtual key management
weight: 10
description: Issue API keys with per-key token budgets and cost tracking (also known as virtual keys).
test:
  virtual-keys:
  - file: content/docs/standalone/latest/llm/cost-controls/virtual-keys.md
    path: virtual-keys
---

{{< reuse "agw-docs/standalone/virtual-keys.md" >}}
