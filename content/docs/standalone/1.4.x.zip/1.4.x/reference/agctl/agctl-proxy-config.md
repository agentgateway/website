---
title: agctl proxy config
weight: 10
description: Reference for the `agctl proxy config` command.
test: skip
---

{{< reuse "agw-docs/pages/reference/agctl/latest/agctl-proxy-config.md" >}}
