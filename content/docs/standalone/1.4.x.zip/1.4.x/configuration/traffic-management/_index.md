---
title: Traffic management
weight: 50
description: Control traffic with matching, redirects, body buffering, rewrites, and transformations.
prev: /configuration/backends
next: /configuration/resiliency
test: skip
---

Control traffic and route requests through agentgateway.

> [!TIP]
> {{< reuse "agw-docs/snippets/policies-gateway-api.md" >}}

{{< reuse "agw-docs/snippets/policy-apply.md" >}}
