---
title: Jaeger
weight: 40
description: Distributed tracing with Jaeger for agentgateway
---

Jaeger is a distributed tracing backend that works with agentgateway's OpenTelemetry integration.

## Quick start

Run Jaeger with Docker:

```bash
docker run -d --name jaeger \
  -p 16686:16686 \
  -p 4317:4317 \
  jaegertracing/all-in-one:latest
```

Configure agentgateway to send traces. The following configuration is from the [`mcp-telemetry` example](https://github.com/agentgateway/agentgateway/tree/main/examples/mcp-telemetry) in the agentgateway repository.

{{% github-yaml url="https://agentgateway.dev/examples/mcp-telemetry/config.yaml" %}}

View traces at [http://localhost:16686](http://localhost:16686).

## Trace information

Agentgateway traces include:

- **HTTP spans**: Request method, URL, status code, duration
- **MCP spans**: Session ID, method name, tool calls
- **LLM spans**: Model, token counts, provider
- **Backend spans**: Upstream connections and responses

## Docker Compose example

The following Compose file runs agentgateway alongside Jaeger. To route traces through an OpenTelemetry Collector instead, see the [Compose file in the `mcp-telemetry` example](https://github.com/agentgateway/agentgateway/blob/main/examples/mcp-telemetry/docker-compose.yaml).

```yaml
version: '3'
services:
  agentgateway:
    image: cr.agentgateway.dev/agentgateway:latest
    ports:
      - "3000:3000"
    volumes:
      - ./config.yaml:/config.yaml:ro
    command: ["-f", "/config.yaml"]
    depends_on:
      - jaeger

  jaeger:
    image: jaegertracing/all-in-one:latest
    ports:
      - "16686:16686"
      - "4317:4317"
    environment:
      - COLLECTOR_OTLP_ENABLED=true
```

## Learn more

{{< cards >}}
  {{< card path="/integrations/observability/opentelemetry" title="OpenTelemetry" subtitle="Configure tracing in agentgateway" >}}
  {{< card path="/llm/observability" title="LLM Observability" subtitle="AI-specific observability" >}}
{{< /cards >}}
