---
linkTitle: "Version 1.4.x"
title: Version 1.4.x
description: Use agentgateway as a standalone binary.
test: skip
---

Welcome to the documentation for using the standalone binary of the agentgateway open source project! 

<br />

{{< reuse "agw-docs/pages/landing.md" >}}
