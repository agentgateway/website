---
title: Non-agentic HTTP traffic
weight: 13
description: Route HTTP traffic to a non-agentic backend such as httpbin with the agentgateway binary.
test:
  non-agentic-http:
  - file: ${versionRoot}/quickstart/non-agentic-http.md
    path: httpbin
---

{{< reuse "agw-docs/standalone/quickstart/non-agentic-http.md" >}}
