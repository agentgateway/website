---
title: FAQs
weight: 200
icon: help_outline
description: Answers to common questions about agentgateway's features, configuration, and deployment.
prev: /docs/reference
--- 

Check out frequently asked questions about agentgateway. 

## What are MCP and A2A? 

{{< reuse "agw-docs/snippets/about-mcp-a2a.md" >}}

## What do MCP and A2A not solve for? 

{{< reuse "agw-docs/snippets/about-mcp-challenges.md" >}}

## What's the problem with traditional API and AI gateways? 

{{< reuse "agw-docs/snippets/about-traditional-gw.md" >}}

## What is agentgateway and why do I want to use it? 

{{< reuse "agw-docs/snippets/about-agw.md" >}}

{{< reuse "agw-docs/snippets/key-benefits.md" >}}

## How do I deploy agentgateway on Kubernetes?

Agentgateway includes a built-in Kubernetes controller, which allows users to use the [Kubernetes Gateway API](https://gateway-api.sigs.k8s.io/) to provision and configure agentgateway proxies.

For more information, see the [Agentgateway on Kubernetes documentation](https://agentgateway.dev/docs/kubernetes/). 

## What's the difference between agentgateway and kagent? 

Agentgateway governs agent-to-tool, agent-to-agent, and agent-to-LLM communication ensuring that these components can securely and reliably talk to each other and exchange data. However, agentgateway assumes that the MCP servers, tools, and agents that you want to access already exist in your environment.

That’s where [kagent](https://kagent.dev) comes in. With kagent, you can quickly develop, build, and run MCP servers and agents directly in Kubernetes. Kagent automates complex DevOps and platform engineering operations for you with out-of-the-box agents and tools, intelligent workflows, and built-in troubleshooting. 

Together, kagent and agentgateway give you all the tools to successfully build a production-ready agentic AI environment that is scalable, reliable, and secure. 

## What license is agentgateway under?

The agentgateway project uses [Apache License 2.0](https://www.apache.org/licenses/).

## What is the project roadmap?

The agentgateway project organizes issues into milestones for each release. For more details, see the following agentgateway links: 
* [Issues](https://github.com/agentgateway/agentgateway/issues)
* [Milestones](https://github.com/agentgateway/agentgateway/milestones)
* [Project board](https://github.com/orgs/agentgateway/projects/1)

## Where is the changelog? 

The changelog is part of each [GitHub release](https://github.com/agentgateway/agentgateway/releases/).

## How do I report a security vulnerability? 

Report vulnerabilities privately by [filing a GitHub security advisory](https://github.com/agentgateway/agentgateway/security/advisories/new). The agentgateway security team reviews each report privately. Do not report security vulnerabilities in public GitHub issues. If you are unsure whether an issue is a security vulnerability, report it privately.

For more details, see the [agentgateway security policy](https://github.com/agentgateway/agentgateway/security/policy). To review vulnerabilities that the project already disclosed, see the [published security advisories](https://github.com/agentgateway/agentgateway/security/advisories).

## Is there enterprise software that is based on agentgateway?

{{< cards >}}
  {{< card link="https://www.solo.io/products/agentgateway" title="Solo.io" icon="external-link">}}
{{< /cards >}}

## What if I have more questions about agentgateway? 

Join the weekly agentgateway [community meeting](https://github.com/agentgateway/agentgateway?tab=readme-ov-file#community-meetings) or engage with the agentgateway community on [Discord](https://discord.com/invite/y9efgEmppm).


