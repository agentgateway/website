---
title: Path
weight: 10
description: Match requests by path using exact, prefix, or regex patterns.
test:
  path-match-exact:
  - file: ${versionRoot}/quickstart/install.md
    path: experimental
  - file: ${versionRoot}/setup/gateway.md
    path: all
  - file: ${versionRoot}/install/sample-app.md
    path: install-httpbin
  - file: ${versionRoot}/traffic-management/match/path.md
    path: path-match-exact
  path-match-prefix:
  - file: ${versionRoot}/quickstart/install.md
    path: experimental
  - file: ${versionRoot}/setup/gateway.md
    path: all
  - file: ${versionRoot}/install/sample-app.md
    path: install-httpbin
  - file: ${versionRoot}/traffic-management/match/path.md
    path: path-match-prefix
  path-match-regex:
  - file: ${versionRoot}/quickstart/install.md
    path: experimental
  - file: ${versionRoot}/setup/gateway.md
    path: all
  - file: ${versionRoot}/install/sample-app.md
    path: install-httpbin
  - file: ${versionRoot}/traffic-management/match/path.md
    path: path-match-regex
---

Match the targeted path of an incoming request against specific path criteria. 

For more information, see the [{{< reuse "agw-docs/snippets/k8s-gateway-api-name.md" >}} documentation](https://gateway-api.sigs.k8s.io/reference/api-types/httproute/#matches).

{{< reuse "agw-docs/snippets/agentgateway/prereq.md" >}}

## Set up exact matching

1. Create an HTTPRoute resource for the `match.example` domain that matches incoming requests on the `/status/200` exact path.
   ```yaml {paths="path-match-exact"}
   kubectl apply -f- <<EOF
   apiVersion: gateway.networking.k8s.io/v1
   kind: HTTPRoute
   metadata:
     name: httpbin-match
     namespace: httpbin
   spec:
     parentRefs:
       - name: agentgateway-proxy
         namespace: {{< reuse "agw-docs/snippets/namespace.md" >}}
     hostnames:
       - match.example
     rules:
       - matches:
         - path:
             type: Exact
             value: /status/200
         backendRefs:
           - name: httpbin
             port: 8000
   EOF
   ```
   
2. Send a request to the `/status/200` path of the httpbin app on the `match.example` domain. Verify that you get back a 200 HTTP response code.  
   {{< tabs >}}
   {{% tab name="Cloud Provider LoadBalancer" %}}
   ```sh
   curl -vi http://$INGRESS_GW_ADDRESS:80/status/200 -H "host: match.example"
   ```
   {{% /tab %}}
   {{% tab name="Port-forward for local testing" %}}
   ```sh
   curl -vi localhost:8080/status/200 -H "host: match.example"
   ```
   {{% /tab %}}
   {{< /tabs >}}

   Example output: 
   ```
   * Request completely sent off
   < HTTP/1.1 200 OK
   HTTP/1.1 200 OK
    access-control-allow-credentials: true
   access-control-allow-credentials: true
   < access-control-allow-origin: *
   access-control-allow-origin: *
   < content-length: 0
   content-length: 0
   ```

3. Send another request to the httpbin app. This time, use the `/headers` path. Because this path is not specified in the HTTPRoute, the request fails and a 404 HTTP response code is returned. 
   {{< tabs >}}
   {{% tab name="Cloud Provider LoadBalancer" %}}
   ```sh
   curl -vi http://$INGRESS_GW_ADDRESS:80/headers -H "host: match.example"
   ```
   {{% /tab %}}
   {{% tab name="Port-forward for local testing" %}}
   ```sh
   curl -vi localhost:8080/headers -H "host: match.example"
   ```
   {{% /tab %}}
   {{< /tabs >}}
   
   Example output: 
   ```
   < HTTP/1.1 404 Not Found
   HTTP/1.1 404 Not Found
   < content-length: 9
   content-length: 9
   < content-type: text/plain; charset=utf-8
   content-type: text/plain; charset=utf-8
   ```
   
{{< doc-test paths="path-match-exact" >}}
for i in $(seq 1 100); do
  curl -s --max-time 5 -o /dev/null "http://${INGRESS_GW_ADDRESS}:80/get" -H "host: match.example" && break
  sleep 2
done
YAMLTest -f - <<'EOF'
- name: wait for httpbin-match HTTPRoute to be accepted
  wait:
    target:
      kind: HTTPRoute
      metadata:
        namespace: httpbin
        name: httpbin-match
    jsonPath: "$.status.parents[0].conditions[?(@.type=='Accepted')].status"
    jsonPathExpectation:
      comparator: equals
      value: "True"
    polling:
      timeoutSeconds: 300
      intervalSeconds: 5
- name: wait for httpbin-match HTTPRoute refs to be resolved
  wait:
    target:
      kind: HTTPRoute
      metadata:
        namespace: httpbin
        name: httpbin-match
    jsonPath: "$.status.parents[0].conditions[?(@.type=='ResolvedRefs')].status"
    jsonPathExpectation:
      comparator: equals
      value: "True"
    polling:
      timeoutSeconds: 300
      intervalSeconds: 5
- name: exact path match - /status/200 returns 200
  retries: 1
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /status/200
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 200
- name: exact path match - /headers returns 404
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /headers
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 404
EOF
{{< /doc-test >}}

## Set up prefix path matching

1. Create an HTTPRoute resource for the `match.example` domain that matches incoming requests on the `/anything` prefix path.
   ```yaml {paths="path-match-prefix"}
   kubectl apply -f- <<EOF
   apiVersion: gateway.networking.k8s.io/v1
   kind: HTTPRoute
   metadata:
     name: httpbin-match
     namespace: httpbin
   spec:
     parentRefs:
       - name: agentgateway-proxy
         namespace: {{< reuse "agw-docs/snippets/namespace.md" >}}
     hostnames:
       - match.example
     rules:
       - matches:
         - path:
             type: PathPrefix
             value: /anything
         backendRefs:
           - name: httpbin
             port: 8000
   EOF
   ```
   
2. Send a request to the `/anything/team1` path of the httpbin app on the `match.example` domain. Verify that you get back a 200 HTTP response code.  
   {{< tabs >}}
   {{% tab name="Cloud Provider LoadBalancer" %}}
   ```sh
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything/team1 -H "host: match.example"
   ```
   {{% /tab %}}
   {{% tab name="Port-forward for local testing" %}}
   ```sh
   curl -vi localhost:8080/anything/team1 -H "host: match.example"
   ```
   {{% /tab %}}
   {{< /tabs >}}

   Example output: 
   ```
   < HTTP/1.1 200 OK
   HTTP/1.1 200 OK
   < access-control-allow-credentials: true
   access-control-allow-credentials: true
   < access-control-allow-origin: *
   access-control-allow-origin: *
   < content-type: application/json; encoding=utf-8
   content-type: application/json; encoding=utf-8
   < content-length: 304
   content-length: 304
   < 

   {
     "args": {},
     "headers": {
       "Accept": [
         "*/*"
       ],
       "Host": [
         "match.example"
       ],
       "User-Agent": [
         "curl/8.7.1"
       ]
     },
     "origin": "10.xxx.x.xx:35204",
     "url": "http://match.example/anything/team1",
     "data": "",
     "files": null,
     "form": null,
     "json": null
   }
   ```

3. Send another request to the httpbin app. This time, use the `/headers` path. Because this path is not specified in the HTTPRoute, the request fails and a 404 HTTP response code is returned. 
   {{< tabs >}}
   {{% tab name="Cloud Provider LoadBalancer" %}}
   ```sh
   curl -vi http://$INGRESS_GW_ADDRESS:80/headers -H "host: match.example"
   ```
   {{% /tab %}}
   {{% tab name="Port-forward for local testing" %}}
   ```sh
   curl -vi localhost:8080/headers -H "host: match.example"
   ```
   {{% /tab %}}
   {{< /tabs >}}
   
   Example output: 
   ```
   < HTTP/1.1 404 Not Found
   HTTP/1.1 404 Not Found
   < content-length: 9
   content-length: 9
   < content-type: text/plain; charset=utf-8
   content-type: text/plain; charset=utf-8
   ```
   
{{< doc-test paths="path-match-prefix" >}}
for i in $(seq 1 100); do
  curl -s --max-time 5 -o /dev/null "http://${INGRESS_GW_ADDRESS}:80/get" -H "host: match.example" && break
  sleep 2
done
YAMLTest -f - <<'EOF'
- name: wait for httpbin-match HTTPRoute to be accepted
  wait:
    target:
      kind: HTTPRoute
      metadata:
        namespace: httpbin
        name: httpbin-match
    jsonPath: "$.status.parents[0].conditions[?(@.type=='Accepted')].status"
    jsonPathExpectation:
      comparator: equals
      value: "True"
    polling:
      timeoutSeconds: 300
      intervalSeconds: 5
- name: wait for httpbin-match HTTPRoute refs to be resolved
  wait:
    target:
      kind: HTTPRoute
      metadata:
        namespace: httpbin
        name: httpbin-match
    jsonPath: "$.status.parents[0].conditions[?(@.type=='ResolvedRefs')].status"
    jsonPathExpectation:
      comparator: equals
      value: "True"
    polling:
      timeoutSeconds: 300
      intervalSeconds: 5
- name: prefix path match - /anything/team1 returns 200
  retries: 1
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything/team1
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 200
- name: prefix path match - /headers returns 404
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /headers
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 404
EOF
{{< /doc-test >}}

## Set up regex matching

Use [RE2 syntax](https://github.com/google/re2/wiki/Syntax) for regular expressions to match incoming requests.

1. Create an HTTPRoute resource for the `match.example` domain that uses a regular expression (regex) to match incoming requests. The following regex patterns are defined in the example: 
   * **`/.*my-path.*`**: 
     * The request path must start with `/`.
     * The expression `.*` means that any character before and after the `my-path` string is allowed. 
     * Allowed pattern: `/anything/this-is-my-path-1`, not allowed: `/anything`. 
   * **`/anything/stores/[^/]+?/entities`**: 
     * The request path must start with `/anything/stores/`. 
     * `[^/]+?` matches any character except `/`.
     * The request path must end with `/entities`.
     * Allowed pattern: `/anything/stores/us/entities`, not allowed: `/anything/stores/us/south/entities`. 
   * **`/anything/(dogs|cats)/\\d[.]\\d.*`**
     * The request path must start with `/anything/`, followed by either `dogs/` or `cats/`.
     * `\\d` matches a single digit.
     * `[.]` matches a literal period.
     * `\\d.*` matches a single digit followed by zero or any character.
     * Allowed pattern: `/anything/dogs/3.0-game`, not allowed: `/anything/birds`
   ```yaml {paths="path-match-regex"}
   kubectl apply -f- <<EOF
   apiVersion: gateway.networking.k8s.io/v1beta1
   kind: HTTPRoute
   metadata:
     name: httpbin-match
     namespace: httpbin
   spec:
     parentRefs:
       - name: agentgateway-proxy
         namespace: {{< reuse "agw-docs/snippets/namespace.md" >}}
     hostnames:
       - "match.example"
     rules:
       - matches:  
         - path:
             type: RegularExpression
             value: /.*my-path.*
         - path:
             type: RegularExpression
             value: /anything/stores/[^/]+?/entities
         - path:
             type: RegularExpression
             value: /anything/(dogs|cats)/\\d[.]\\d.*
         backendRefs:
         - name: httpbin
           namespace: httpbin
           port: 8000
   EOF
   ```
   
2. Send multiple requests to the httpbin app on the `match.example` domain. 
   * `/anything/this-is-my-path-1` matches the regex pattern `\/.*my-path.*` 
   * `/anything/stores/us/entities` matches the regex pattern `/anything/stores/[^/]+?/entities` 
   * `/anything/dogs/3.0-game` matches the regex pattern `/anything/(dogs|cats)/\\d[.]\\d.*`
   
   Verify that the requests succeed and that you get back a 200 HTTP response code.  
   {{< tabs >}}
   {{% tab name="Cloud Provider LoadBalancer" %}}
   ```sh
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything/this-is-my-path-1 -H "host: match.example"
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything/stores/us/entities -H "host: match.example"
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything/dogs/3.0-game -H "host: match.example"
   ```
   {{% /tab %}}
   {{% tab name="Port-forward for local testing" %}}
   ```sh
   curl -vi localhost:8080/anything/this-is-my-path-1 -H "host: match.example"
   curl -vi localhost:8080/anything/stores/us/entities -H "host: match.example"
   curl -vi localhost:8080/anything/dogs/3.0-game -H "host: match.example"
   ```
   {{% /tab %}}
   {{< /tabs >}}

   Example output: 
   ```
   < HTTP/1.1 200 OK
   HTTP/1.1 200 OK
   < access-control-allow-credentials: true
   access-control-allow-credentials: true
   < access-control-allow-origin: *
   access-control-allow-origin: *
   < content-type: application/json; encoding=utf-8
   content-type: application/json; encoding=utf-8
   < content-length: 317
   content-length: 317
   < 

   {
     "args": {},
     "headers": {
      "Accept": [
            "*/*"
       ],
       "Host": [
        "match.example"
       ],
       "User-Agent": [
         "curl/8.7.1"
       ]
     },
     "origin": "10.xxx.x.xx:43182",
     "url": "http://match.example/anything/stores/us/entities",
     "data": "",
     "files": null,
     "form": null,
     "json": null
   }
   ```

3. Send requests to the httpbin app that do not meet the defined regex patterns.
   * `/anything` does not match the regex pattern `\/.*my-path.*` 
   * `/anything/stores/us/south/entities` does not match the regex pattern `/anything/stores/[^/]+?/
   * `/anything/birds/1.1-game` does not match the regex pattern `/anything/(dogs|cats)/\\d[.]\\d.*`
   
   Verify that all requests fail with a 404 HTTP response code, because the path does not match the regex pattern that you defined. 
   {{< tabs >}}
   {{% tab name="Cloud Provider LoadBalancer" %}}
   ```sh
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything -H "host: match.example"
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything/stores/us/south/entities -H "host: match.example"
   curl -vi http://$INGRESS_GW_ADDRESS:80/anything/birds/1.1-game -H "host: match.example"
   ```
   {{% /tab %}}
   {{% tab name="Port-forward for local testing" %}}
   ```sh
   curl -vi localhost:8080/anything -H "host: match.example"
   curl -vi localhost:8080/anything/stores/us/south/entities -H "host: match.example"
   curl -vi localhost:8080/anything/birds/1.1-game -H "host: match.example"
   ```
   {{% /tab %}}
   {{< /tabs >}}

   Example output: 
   ```
   < HTTP/1.1 404 Not Found
   HTTP/1.1 404 Not Found
   < content-length: 9
   content-length: 9
   < content-type: text/plain; charset=utf-8
   content-type: text/plain; charset=utf-8
   ```


{{< doc-test paths="path-match-regex" >}}
for i in $(seq 1 100); do
  curl -s --max-time 5 -o /dev/null "http://${INGRESS_GW_ADDRESS}:80/get" -H "host: match.example" && break
  sleep 2
done
YAMLTest -f - <<'EOF'
- name: wait for httpbin-match HTTPRoute to be accepted
  wait:
    target:
      kind: HTTPRoute
      metadata:
        namespace: httpbin
        name: httpbin-match
    jsonPath: "$.status.parents[0].conditions[?(@.type=='Accepted')].status"
    jsonPathExpectation:
      comparator: equals
      value: "True"
    polling:
      timeoutSeconds: 300
      intervalSeconds: 5
- name: wait for httpbin-match HTTPRoute refs to be resolved
  wait:
    target:
      kind: HTTPRoute
      metadata:
        namespace: httpbin
        name: httpbin-match
    jsonPath: "$.status.parents[0].conditions[?(@.type=='ResolvedRefs')].status"
    jsonPathExpectation:
      comparator: equals
      value: "True"
    polling:
      timeoutSeconds: 300
      intervalSeconds: 5
- name: regex path match - /anything/this-is-my-path-1 returns 200
  retries: 1
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything/this-is-my-path-1
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 200
- name: regex path match - /anything/stores/us/entities returns 200
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything/stores/us/entities
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 200
- name: regex path match - /anything/dogs/3.0-game returns 200
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything/dogs/3.0-game
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 200
- name: regex path match - /anything returns 404
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 404
- name: regex path match - /anything/stores/us/south/entities returns 404
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything/stores/us/south/entities
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 404
- name: regex path match - /anything/birds/1.1-game returns 404
  http:
    url: "http://${INGRESS_GW_ADDRESS}:80"
    path: /anything/birds/1.1-game
    method: GET
    headers:
      host: match.example
  source:
    type: local
  expect:
    statusCode: 404
EOF
{{< /doc-test >}}

## Cleanup

{{< reuse "agw-docs/snippets/cleanup.md" >}}

```sh
kubectl delete httproute httpbin-match -n httpbin --ignore-not-found
```



