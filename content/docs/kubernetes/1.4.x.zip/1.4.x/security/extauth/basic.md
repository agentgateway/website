---
title: Basic auth
weight: 10
description: Set up basic auth to secure requests to an LLM, MCP server, or agent.
---

{{< reuse "agw-docs/pages/security/basic-auth.md" >}}