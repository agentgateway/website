---
title: Monitoring agentgateway proxies for NACKs
description: Monitor and troubleshoot proxy configuration rejections with metrics and events.
weight: 80
test:
  nacks:
  - file: ${versionRoot}/quickstart/install.md
    path: standard
  - file: ${versionRoot}/setup/gateway.md
    path: all
  - file: ${versionRoot}/observability/nacks.md
    path: nacks
---

{{< reuse "agw-docs/pages/agentgateway/monitoring-agentgateway-nacks.md" >}}
