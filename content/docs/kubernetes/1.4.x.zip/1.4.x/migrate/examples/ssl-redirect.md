---
title: "SSL Redirect"
description: Convert NGINX SSL redirect annotations to Gateway API HTTP redirect filters.
weight: 50
---

The `ssl-redirect` annotation tells NGINX to redirect HTTP to HTTPS. In Gateway API, this becomes a `RequestRedirect` filter on the HTTPRoute.

## Before: Ingress with SSL redirect

```bash
cat <<'EOF' > ssl-redirect-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ssl-redirect-demo
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
spec:
  ingressClassName: nginx
  rules:
  - host: secure.example.com
    http:
      paths:
      - backend:
          service:
            name: web-app
            port:
              number: 8080
        path: /
        pathType: Prefix
EOF
```

## Convert

```bash
ingress2gateway print --providers=ingress-nginx --emitter=agentgateway \
  --input-file ssl-redirect-ingress.yaml > ssl-redirect-agentgateway.yaml
```

## After: HTTPRoute(s) with redirect

```bash
cat ssl-redirect-agentgateway.yaml
```

With the agentgateway emitter, SSL redirect is implemented by **splitting** the route: an HTTP route includes a `RequestRedirect` filter (301 to HTTPS) with no backends, and a separate HTTPS route carries the backend traffic. Shown below is the HTTP redirect route:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: ssl-redirect-demo-secure-example-com
spec:
  hostnames:
  - secure.example.com
  parentRefs:
  - name: nginx
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /
    filters:
    - type: RequestRedirect
      requestRedirect:
        scheme: https
        statusCode: 301
```

> [!NOTE]
> NGINX uses status code 308 by default, but Gateway API standardizes on 301.

## Apply

```bash
kubectl apply -f ssl-redirect-agentgateway.yaml
```
