---
title: OpenAI-compatible providers
weight: 20
description: Configure providers without built-in support that expose the OpenAI API format, such as Perplexity.
---

> [!NOTE]
> Use the `openai` provider type for providers without a first-class page that
> behave like OpenAI for the APIs that you need. If agentgateway already has a
> dedicated provider page, use that page instead of re-creating the provider as an
> OpenAI-compatible backend. If the upstream supports only a subset of OpenAI
> APIs, supports multiple API shapes, or needs non-default per-format paths, use
> a [custom provider]({{< link-hextra path="/llm/providers/custom/" >}}) instead.

{{< reuse "agw-docs/pages/agentgateway/llm/providers/openai-compatible.md" >}}
