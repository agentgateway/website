---
title: Version 1.4.x
weight: 460
description: Use agentgateway in a Kubernetes environment. 
test: skip
---

Welcome to the documentation for using agentgateway on Kubernetes!

<br />

{{< reuse "agw-docs/pages/landing.md" >}}
